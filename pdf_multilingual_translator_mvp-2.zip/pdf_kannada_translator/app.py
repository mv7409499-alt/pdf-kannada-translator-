import os, re, tempfile
from flask import Flask, render_template, request, send_file, flash, redirect
from pypdf import PdfReader
from deep_translator import GoogleTranslator
from docx import Document
from reportlab.lib.pagesizes import A4
from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer
from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont
from xml.sax.saxutils import escape

app = Flask(__name__)
app.secret_key = os.environ.get("SECRET_KEY", "replace-before-public-deployment")
MAX_MB = int(os.environ.get("MAX_UPLOAD_MB", "30"))
app.config["MAX_CONTENT_LENGTH"] = MAX_MB * 1024 * 1024

def split_text(text, limit=3500):
    out, current = [], ""
    for p in re.split(r"\\n+", text):
        p = p.strip()
        while len(p) > limit:
            cut = p.rfind(" ", 0, limit)
            if cut < 1: cut = limit
            if current: out.append(current); current = ""
            out.append(p[:cut].strip()); p = p[cut:].strip()
        if p:
            if len(current) + len(p) + 1 > limit:
                if current: out.append(current)
                current = p
            else: current = (current + "\\n" + p).strip()
    if current: out.append(current)
    return out

def font_path():
    for p in [os.environ.get("KANNADA_FONT",""),
              "/usr/share/fonts/truetype/noto/NotoSansKannada-Regular.ttf",
              "/usr/share/fonts/truetype/noto/NotoSansKannadaUI-Regular.ttf",
              os.path.join(os.path.dirname(__file__),"NotoSansKannada-Regular.ttf")]:
        if p and os.path.isfile(p): return p
    return None

def make_pdf(pages, path):
    fp = font_path()
    if not fp: raise RuntimeError("Kannada font not installed")
    try: pdfmetrics.registerFont(TTFont("Kannada", fp))
    except Exception: pass
    styles = getSampleStyleSheet()
    body = ParagraphStyle("KnBody", parent=styles["BodyText"], fontName="Kannada", fontSize=10, leading=15, spaceAfter=7)
    title = ParagraphStyle("KnTitle", parent=styles["Title"], fontName="Kannada", fontSize=16, leading=22)
    story = [Paragraph("ಕನ್ನಡಕ್ಕೆ ಅನುವಾದಿಸಿದ PDF", title), Spacer(1, 12)]
    for n, t in pages:
        story.append(Paragraph(f"ಮೂಲ PDF ಪುಟ {n}", body))
        for line in t.splitlines():
            if line.strip(): story.append(Paragraph(escape(line), body))
        story.append(Spacer(1, 8))
    SimpleDocTemplate(path, pagesize=A4, rightMargin=40, leftMargin=40, topMargin=40, bottomMargin=40).build(story)

LANGUAGES = [
    ("auto", "ಸ್ವಯಂಚಾಲಿತವಾಗಿ ಪತ್ತೆಮಾಡು (Auto Detect)"),
    ("af", "Afrikaans"), ("sq", "Albanian"), ("am", "Amharic"), ("ar", "Arabic"),
    ("hy", "Armenian"), ("az", "Azerbaijani"), ("eu", "Basque"), ("be", "Belarusian"),
    ("bn", "Bengali"), ("bs", "Bosnian"), ("bg", "Bulgarian"), ("ca", "Catalan"),
    ("ceb", "Cebuano"), ("zh-CN", "Chinese (Simplified)"), ("zh-TW", "Chinese (Traditional)"),
    ("co", "Corsican"), ("hr", "Croatian"), ("cs", "Czech"), ("da", "Danish"),
    ("nl", "Dutch"), ("en", "English"), ("eo", "Esperanto"), ("et", "Estonian"),
    ("fi", "Finnish"), ("fr", "French"), ("fy", "Frisian"), ("gl", "Galician"),
    ("ka", "Georgian"), ("de", "German"), ("el", "Greek"), ("gu", "Gujarati"),
    ("ht", "Haitian Creole"), ("ha", "Hausa"), ("haw", "Hawaiian"), ("he", "Hebrew"),
    ("hi", "Hindi"), ("hmn", "Hmong"), ("hu", "Hungarian"), ("is", "Icelandic"),
    ("ig", "Igbo"), ("id", "Indonesian"), ("ga", "Irish"), ("it", "Italian"),
    ("ja", "Japanese"), ("jv", "Javanese"), ("kn", "Kannada"), ("kk", "Kazakh"),
    ("km", "Khmer"), ("rw", "Kinyarwanda"), ("ko", "Korean"), ("ku", "Kurdish"),
    ("ky", "Kyrgyz"), ("lo", "Lao"), ("la", "Latin"), ("lv", "Latvian"),
    ("lt", "Lithuanian"), ("lb", "Luxembourgish"), ("mk", "Macedonian"), ("mg", "Malagasy"),
    ("ms", "Malay"), ("ml", "Malayalam"), ("mt", "Maltese"), ("mi", "Maori"),
    ("mr", "Marathi"), ("mn", "Mongolian"), ("my", "Myanmar (Burmese)"), ("ne", "Nepali"),
    ("no", "Norwegian"), ("ny", "Nyanja"), ("or", "Odia"), ("ps", "Pashto"),
    ("fa", "Persian"), ("pl", "Polish"), ("pt", "Portuguese"), ("pa", "Punjabi"),
    ("ro", "Romanian"), ("ru", "Russian"), ("sm", "Samoan"), ("gd", "Scots Gaelic"),
    ("sr", "Serbian"), ("st", "Sesotho"), ("sn", "Shona"), ("sd", "Sindhi"),
    ("si", "Sinhala"), ("sk", "Slovak"), ("sl", "Slovenian"), ("so", "Somali"),
    ("es", "Spanish"), ("su", "Sundanese"), ("sw", "Swahili"), ("sv", "Swedish"),
    ("tl", "Filipino"), ("tg", "Tajik"), ("ta", "Tamil"), ("tt", "Tatar"),
    ("te", "Telugu"), ("th", "Thai"), ("tr", "Turkish"), ("tk", "Turkmen"),
    ("uk", "Ukrainian"), ("ur", "Urdu"), ("uz", "Uzbek"), ("vi", "Vietnamese"),
    ("cy", "Welsh"), ("xh", "Xhosa"), ("yi", "Yiddish"), ("yo", "Yoruba"), ("zu", "Zulu")
]

@app.route("/")
def home(): return render_template("index.html", max_mb=MAX_MB, languages=LANGUAGES)

@app.route("/translate", methods=["POST"])
def translate():
    f = request.files.get("pdf")
    source, target = request.form.get("source","auto"), request.form.get("target","kn")
    if not f or not f.filename.lower().endswith(".pdf"):
        flash("PDF ಫೈಲ್ ಆಯ್ಕೆಮಾಡಿ."); return redirect("/")
    try:
        reader = PdfReader(f)
        if len(reader.pages) > 30:
            flash(f"ಒಂದು ಬಾರಿ ಗರಿಷ್ಠ 30 ಪುಟಗಳು. ನಿಮ್ಮ ಫೈಲ್‌ನಲ್ಲಿ {len(reader.pages)} ಪುಟಗಳಿವೆ; ಮೊದಲು ಭಾಗಗಳಾಗಿ ವಿಭಜಿಸಿ."); return redirect("/")
        translator = GoogleTranslator(source=source, target=target)
        pages = []
        for i, page in enumerate(reader.pages, 1):
            raw = (page.extract_text() or "").strip()
            if not raw: translated = "[ಈ ಪುಟದ ಪಠ್ಯವನ್ನು ಹೊರತೆಗೆಯಲಾಗಲಿಲ್ಲ; ಸ್ಕ್ಯಾನ್ ಮಾಡಿದ ಪುಟವಾಗಿರಬಹುದು.]"
            else: translated = "\\n\\n".join(translator.translate(chunk) or "" for chunk in split_text(raw))
            pages.append((i, translated))
        with tempfile.TemporaryDirectory() as td:
            docx = os.path.join(td, "translated_kannada.docx")
            pdf = os.path.join(td, "translated_kannada.pdf")
            d = Document(); d.add_heading("ಕನ್ನಡಕ್ಕೆ ಅನುವಾದಿಸಿದ PDF", 0)
            for n, t in pages:
                d.add_heading(f"ಮೂಲ PDF ಪುಟ {n}", level=2); d.add_paragraph(t)
            d.save(docx)
            try:
                make_pdf(pages, pdf)
                return send_file(pdf, as_attachment=True, download_name="translated_kannada.pdf")
            except Exception:
                return send_file(docx, as_attachment=True, download_name="translated_kannada.docx")
    except Exception as e:
        flash("ಅನುವಾದ ವಿಫಲವಾಗಿದೆ: " + str(e)[:180] + ". ಇಂಟರ್ನೆಟ್ ಅಥವಾ ಉಚಿತ ಅನುವಾದ ಸೇವೆಯ ಮಿತಿಯನ್ನು ಪರಿಶೀಲಿಸಿ.")
        return redirect("/")

@app.errorhandler(413)
def too_big(e):
    flash(f"ಫೈಲ್ ಮಿತಿ {MAX_MB} MB ಮೀರಿದೆ."); return redirect("/")

if __name__ == "__main__":
    app.run(host="0.0.0.0", port=int(os.environ.get("PORT","5000")))
