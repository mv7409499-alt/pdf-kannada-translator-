# Multilingual PDF Translator — starter MVP

This starter website offers language selection for a wide set of languages supported by the underlying translation service, automatic source-language detection, PDF text extraction, and translated PDF/DOCX output.

## Run locally
Install Python 3.10+, then:
`pip install -r requirements.txt`
`python app.py`
Open `http://127.0.0.1:5000`.

## Important limitations
- Translation uses `deep-translator` and an unofficial Google Translate web interface; it may rate-limit, change, or stop working. Language availability may vary.
- Up to 30 pages per request in this starter version.
- Scanned/image-only PDFs need OCR, not included.
- Original layout, images, and exact formatting are not preserved.
- For public deployment, set a strong SECRET_KEY, configure upload limits, add abuse protection/timeouts, and use a supported translation API if reliability is needed.
- Kannada PDF output needs Noto Sans Kannada installed; otherwise the app returns a DOCX fallback.
